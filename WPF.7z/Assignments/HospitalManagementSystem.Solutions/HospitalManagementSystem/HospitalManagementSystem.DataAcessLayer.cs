﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows;

namespace HospitalManagementSystem
{
    class HospitalManagementSystem1
    {
        public void Adddetails(string patientName, string patientType,int patientId)
        {
          using ( SqlConnection sqlcon = new SqlConnection(@"Data source=ndamssql\sqlilearn; user id=sqluser;password=sqluser; Initial Catalog=Training_19Sep18_Pune;"))
            {
                sqlcon.Open();
                SqlCommand sqlcom = new SqlCommand();
                sqlcom.CommandText = @"Insert Into Shanu_Patient(PatientId,patientName,PatientType) values(@patientId,@patientName,@patientType)";


                SqlParameter pId = sqlcom.Parameters.Add("@patientId", SqlDbType.Int);
                pId.Value = patientId;


                SqlParameter pName = sqlcom.Parameters.Add("@PatientName", SqlDbType.VarChar);
                pName.Value = patientName;

                SqlParameter pType = sqlcom.Parameters.Add("PatientType", SqlDbType.VarChar);
                pType.Value = patientType;

                sqlcom.Connection = sqlcon;
                sqlcom.ExecuteNonQuery();
                MessageBox.Show("data saved");


            }






        }
        


    }
}
