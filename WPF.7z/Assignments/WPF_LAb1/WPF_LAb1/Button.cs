﻿namespace WPF_LAb1
{
    internal class Button
    {
        public string Content { get; internal set; }
    }
}