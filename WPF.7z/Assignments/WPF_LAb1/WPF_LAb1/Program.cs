﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_LAb1
{
    class Program
    {
        static void Main(string[] args)
        {
            Window mainWindow = new Window();
            mainWindow.Title = "WPF Application";
            Button button1 = new Button();
            button1.Content = "Click Me!";
            mainWindow.Content = button1;
            Application app = new Application();
            app.Run(mainWindow);
        }
    }

    internal class Application
    {
        internal void Run(Window mainWindow)
        {
            Console.WriteLine("Hello Task 1 Completed.........");
        }
    }
}
